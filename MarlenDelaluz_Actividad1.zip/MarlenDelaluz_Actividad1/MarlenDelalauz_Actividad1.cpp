#include <iostream>
#include <string>
using namespace std;
int main() {
    string nombre;
    int edad;
    cout << "Ingrese su nombre: ";
getline(cin, nombre);
cout << "Ingrese su edad: ";
cin >> edad;
if (edad >= 18){
    cout << "Bienvenido " << nombre << ", Eres mayor de edad " << endl; 
     } else  { 
    cout << "Bienvenido " << nombre << " , Eres menor de edad " << endl;
     }
     return 0;
      }
      